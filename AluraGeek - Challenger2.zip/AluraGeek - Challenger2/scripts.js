// scripts.js
document.addEventListener('DOMContentLoaded', () => {
    const addButtons = document.querySelectorAll('.product-item button');
    const cartSection = document.querySelector('.shopping-cart');

    addButtons.forEach(button => {
        button.addEventListener('click', () => {
            const productItem = button.parentElement;
            const productName = productItem.querySelector('h3').innerText;
            const productPrice = productItem.querySelector('p:nth-of-type(2)').innerText;

            const cartItem = document.createElement('div');
            cartItem.classList.add('cart-item');
            cartItem.innerHTML = `
                <img src="${productItem.querySelector('img').src}" alt="${productName}">
                <h3>${productName}</h3>
                <p>${productPrice}</p>
                <button>Eliminar</button>
            `;

            cartSection.appendChild(cartItem);
            updateTotal();

            cartItem.querySelector('button').addEventListener('click', () => {
                cartSection.removeChild(cartItem);
                updateTotal();
            });
        });
    });

    function updateTotal() {
        let total = 0;
        const cartItems = document.querySelectorAll('.cart-item');
        cartItems.forEach(item => {
            const price = parseFloat(item.querySelector('p').innerText.replace('$', ''));
            total += price;
        });
        document.querySelector('.cart-total h3').innerText = `Total: $${total.toFixed(2)}`;
    }
});
